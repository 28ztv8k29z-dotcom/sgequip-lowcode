# Documentação e Diagramas

Diagrama ER gerado: diagrama_er_sgequip.pdf

Instruções:
- Abra o PDF para visualizar o Diagrama ER do SGequip.
- Use este diagrama como referência para criar as listas no SharePoint antes de montar o app no Power Apps.
